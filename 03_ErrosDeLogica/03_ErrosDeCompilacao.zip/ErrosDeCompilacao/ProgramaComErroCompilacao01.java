
/**
 * Write a description of class ProgramaComErroCompilacao01 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class ProgramaComErroCompilacao01
{
    Public static void main(String args[]){
        System.out.println("\fParabéns! Conseguiste corrigir o erro de sintaxe que é identificado em tempo de compilação. ");
    }
 
}
