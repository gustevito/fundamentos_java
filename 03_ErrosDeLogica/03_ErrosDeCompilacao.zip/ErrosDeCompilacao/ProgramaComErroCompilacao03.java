
public class ProgramaComErroCompilacao03
{
    public static void main(String args[])
        System.out.println("\fExcelente! Mais um programa sem erros. ");
    }
 
}
