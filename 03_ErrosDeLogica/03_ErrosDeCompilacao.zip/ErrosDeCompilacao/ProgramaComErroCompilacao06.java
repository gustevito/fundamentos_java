public class ProgramaComErroCompilacao06
{
   
        System.out.println("\fFantástico!!!! Corrigiste mais um programa! ");
    
 
}
