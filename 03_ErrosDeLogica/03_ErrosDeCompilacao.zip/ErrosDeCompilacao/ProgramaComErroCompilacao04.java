public class ProgramaComErroCompilacao04
{
    public static void main(String args[]){
        system.out.println("\fÓtimo!! Mais um programa sem erros de compilação.");
    }
 
}
