public class ProgramaComErroCompilacao02
{
    public static void main(String args[]){
        System.out.println("\fLegal! Conseguiste corrigir outro erro de sintaxe. ")
    }
 
}
