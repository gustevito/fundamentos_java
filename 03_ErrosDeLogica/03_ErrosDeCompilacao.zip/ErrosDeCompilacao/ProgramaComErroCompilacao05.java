public ProgramaComErroCompilacao05
{
    public static void main(String args[]){
        System.out.println("\fShow!! Estás ficando com nisso!");
    }
 
}
