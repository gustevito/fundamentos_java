import java.util.Scanner;
public class ProgramaComErroCompilacao08
{
    public static void main(String args[]){
        Scanner entrada = new Scanner(System.in);
        System.out.println("\fInforme um valor inteiro: ");
        int valor = entrada.nextInt();
        System.out.println("Você digitou o número inteiro: " + valor1);
    }
 
}
